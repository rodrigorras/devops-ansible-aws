


<html>
<body>
<?php $Field1= $_POST["name"]; ?>
<?php $Field2= $_POST["email"]; ?>
<?php $Field3= $_POST["phone"]; ?>
<?php $Field4= $_POST["message"]; ?>


Welcome <?php echo $_POST["name"]; ?><br>
Your email address is: <?php echo $_POST["email"]; ?>



<?php
$servername = "vanhackrodrigorios.cqpghvkisof6.us-east-1.rds.amazonaws.com";
$username = "admin";
$password = "1nsecure";
$dbname = "vanhack";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "INSERT INTO user (username, email,phone,message)
VALUES ('$Field1', '$Field2', '$Field3','$Field4')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>

</body>
</html>
